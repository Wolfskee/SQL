﻿# Host: localhost  (Version: 5.5.53)
# Date: 2020-04-13 22:05:47
# Generator: MySQL-Front 5.3  (Build 4.234)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "book"
#

CREATE TABLE `book` (
  `book_id` int(11) NOT NULL AUTO_INCREMENT,
  `book_name` varchar(100) DEFAULT NULL COMMENT 'the title of a book',
  `book_ISBN` varchar(50) DEFAULT NULL,
  `book_author` varchar(30) DEFAULT NULL,
  `book_genre` varchar(100) DEFAULT NULL,
  `pub_id` int(5) DEFAULT NULL,
  `book_numberOfPages` int(11) DEFAULT NULL,
  `book_price` double(5,2) DEFAULT '0.00',
  `book_stock` int(11) DEFAULT '0',
  PRIMARY KEY (`book_id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;

#
# Data for table "book"
#

INSERT INTO `book` VALUES (1,'King Arthur\'s Modern Return ','B00JVSJUI0','Debra N. Mancoff ',NULL,1,266,436.08,99),(3,'Effective Java','B078H61SCH','Joshua Bloch','Java',2,306,25.00,52),(4,'Head First Java','B009KCUX3S','Kathy Sierra','Java',3,688,31.18,82),(5,'Mastering Go','B07WC24RTQ','Mihalis Tsoukalos','GO',4,798,99.75,100),(6,'Black Hat Go','B073NPY29N','Tom Steele','GO',5,368,23.99,75),(7,'Fortitude: American Resilience in the Era of Outrage','1538733307','Dan Crenshaw','fiction',6,256,21.90,35),(8,'Arguing with Socialists','198214050X','Glenn Beck','politics',7,416,21.96,10),(9,'Wild Remedies: How to Forage Healing Foods and Craft Your Own Herbal Medicine','1401956882','Rosalee de la Forêt','medicine',6,424,19.89,75),(10,'Animal Crossing: New Horizons Official Companion Guide','3869931000','Future Press','Video games and computer games',7,432,19.70,75),(11,'Masked Prey','0525539522','John Sandford','fiction',5,416,17.90,62),(12,'More Myself: A Journey','1250153298','Alicia Keys','Art biography',4,272,29.60,75),(13,'Food Network Magazine The Big, Fun Kids Cookbook: 150+ Recipes for Young Chefs','1950785041','FOOD NETWORK MAGAZINE','cooking',3,192,13.00,86),(14,'Walk the Wire','1538761467','David Baldacci','fiction',2,432,20.30,42),(15,'Dog Man: Grime and Punishment: From the Creator of Captain Underpants','1338535625','Dav Pilkey','cartoon',1,240,11.69,86),(25,'1','1','1','1',2,1,1.00,1);

#
# Structure for table "car"
#

CREATE TABLE `car` (
  `user_id` int(11) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL,
  `buy_num` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# Data for table "car"
#

INSERT INTO `car` VALUES (1,7,1),(1,24,1);

#
# Structure for table "logis_detl"
#

CREATE TABLE `logis_detl` (
  `logis_detl_id` int(11) NOT NULL AUTO_INCREMENT,
  `logis_id` varchar(15) DEFAULT NULL,
  `logis_info` varchar(255) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  PRIMARY KEY (`logis_detl_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

#
# Data for table "logis_detl"
#

INSERT INTO `logis_detl` VALUES (3,'8273018','To send the goods~','2020-04-12 00:00:00'),(4,'3732229','Warehouse delivered','2020-04-13 14:29:09'),(5,'5784168','To send the goods~','2020-04-12 00:00:00'),(6,'1743411','To send the goods~','2020-04-12 00:00:00'),(8,'7483086','To send the goods~','2020-04-13 13:51:59'),(9,'6468875','To send the goods~','2020-04-13 16:31:20');

#
# Structure for table "order"
#

CREATE TABLE `order` (
  `order_id` varchar(15) NOT NULL DEFAULT '',
  `user_id` int(11) DEFAULT NULL,
  `buy_time` datetime DEFAULT NULL,
  `order_status` int(2) DEFAULT '0',
  `order_address` varchar(100) DEFAULT NULL,
  `order_phone` varchar(20) DEFAULT NULL,
  `order_remarks` varchar(255) DEFAULT NULL,
  `logis_id` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

#
# Data for table "order"
#

INSERT INTO `order` VALUES ('2139514',6,'2020-04-13 13:51:59',0,'xxxx','xxxx',NULL,'7483086'),('4090737',6,'2020-04-12 18:54:31',0,'1','1',NULL,'1743411'),('6788346',6,'2020-04-12 18:44:06',0,'1','1',NULL,'8273018'),('6798837',6,'2020-04-12 18:44:58',0,'2','2',NULL,'3732229'),('6931566',6,'2020-04-12 18:48:55',0,'123','123',NULL,'5784168'),('8679361',6,'2020-04-13 16:31:20',0,'ee','ee','remarks','6468875');

#
# Structure for table "order_detl"
#

CREATE TABLE `order_detl` (
  `order_detl_id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(15) DEFAULT NULL,
  `book_id` int(11) DEFAULT NULL,
  `buy_num` int(11) DEFAULT NULL,
  `buy_amout` int(11) DEFAULT NULL,
  PRIMARY KEY (`order_detl_id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

#
# Data for table "order_detl"
#

INSERT INTO `order_detl` VALUES (7,'6788346',6,3,24),(8,'6798837',10,7,20),(9,'6931566',4,12,31),(10,'6931566',7,1,22),(11,'6931566',3,17,25),(12,'4090737',4,8,31),(13,'2394798',6,20,24),(14,'2139514',12,20,30),(15,'8679361',5,42,100);

#
# Structure for table "publisher"
#

CREATE TABLE `publisher` (
  `pub_id` int(11) NOT NULL AUTO_INCREMENT,
  `pub_name` varchar(30) DEFAULT NULL,
  `pub_address` varchar(100) DEFAULT NULL,
  `pub_email` varchar(20) DEFAULT NULL,
  `pub_phone` varchar(20) DEFAULT NULL,
  `pub_account` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`pub_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

#
# Data for table "publisher"
#

INSERT INTO `publisher` VALUES (1,'Routledge','Routledge xxxx','Routledge@ww.com','4546885','777777777777777777'),(2,'Addison-Wesley Professional','Addison-Wesley Professional xxxx','Professional@ww.com','5566555','666666666666666666'),(3,'O\'Reilly Media','O\'Reilly Media xxxx','Media@ww.com','5465445','555555555555555555'),(4,'Packt Publishing','Packt Publishing xxxx','PackPublishing@ww.co','8565429','444444444444444444'),(5,'No Starch Press','No Starch Press xxxx','NoStarchPress@ww.com','8654482','333333333333333333'),(6,'fiction','fiction xxxx','fiction@ww.com','5668521','222222222222222222'),(7,'Threshold Editions','Threshold Editions XXXX','Threshold Editions@w','1565854','111111111111111111'),(12,'test','test','test','test','test');

#
# Structure for table "user"
#

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(20) DEFAULT NULL,
  `password` varchar(30) DEFAULT NULL,
  `user_phone` varchar(20) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `permission` int(2) DEFAULT '0',
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

#
# Data for table "user"
#

INSERT INTO `user` VALUES (6,'1','1','1','1',0),(7,'admin','admin','#','#',1),(11,'2','2','2','2',0);
