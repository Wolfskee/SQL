package Utlis;
import java.lang.reflect.Field;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBUtlis {
    /**
     * 《如果  Javabean 属性名 和数据表列名 不相同 可以在执行SQL中表明返回结果集列的别名》
     *  声明别名：SELECT User_HUAWEI User,Name_HUANWEI Name FROM Users WHERE ....
     *
     * getColumnLabel()    获取表的列的别名;
     * String getColumnLabel(int column)
     *       获取指定列的建议标题用于打印输出和显示。 建议的标题通常由SQL AS子句AS 。
     *       如果SQL AS没有指定，从返回的值getColumnLabel将是相同的由返回的值getColumnName方法。
     * */

    private static final String DRIVERCLASS = "com.mysql.cj.jdbc.Driver";
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/line?serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "root";

    /**
     * 数据库连接
     * */
    private static Connection conn;
    public Connection Connection(){
        try {
            Class.forName(DRIVERCLASS);
            conn = DriverManager.getConnection(URL,USER,PASSWORD);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(conn!=null){
            System.out.println("数据库连接成功！");
        }
        return conn;
    }
    /**
     * 数据库操作
     * */
    //增删改
    public int RUD(Connection conn, String sql, Object ... args){
        PreparedStatement statement = null;
        try {
            statement = conn.prepareStatement(sql);         //PreparedStatement对象可以预先处理给定的SQL语句
            for(int i =0;i<args.length;i++){
                statement.setObject(i+1,args[i]);
            }
            //statement.execute();                //执行SQL语句         (没有返回结果，无法确定sql语句是否成功操作了数据库)
            int affect = statement.executeUpdate();     //返回执行sql语句影响数据表的行数；
            return affect;
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            PreparedStatementClose(statement);      //资源关闭
        }
        return 0;
    }
    //查询操作
    public <T> List Queue(Connection conn, String sql,Class<T> clazz, Object ... args){
        try {
            PreparedStatement preparedStatement = conn.prepareStatement(sql);           //预先处理给定的SQL语句
            for(int i=0;i<args.length;i++){
                preparedStatement.setObject(i+1,args[i]);               //填写占位符
            }
            //获取到结果集
            ResultSet resultSet = preparedStatement.executeQuery();
            //可用于获取有关ResultSet对象中列的类型和属性的信息的对象
            ResultSetMetaData resultSetMetaData = resultSet.getMetaData();
            //ResultSetMetaData  结果集的元数据;
            List<T> list = new ArrayList<>();
            int col = resultSetMetaData.getColumnCount();
            while (resultSet.next()){
                T t ;
                try {
                    t= clazz.newInstance();
                } catch (Exception e){
                    t = (T) String.class.newInstance();
                }
                for(int i=0;i<col;i++) {
                    //获取列的值
                    Object columValue = resultSet.getObject(i+1);
                    //获取每个列的名
                    String columName = resultSetMetaData.getColumnName(i+1);
                    Field field = clazz.getDeclaredField(columName);
                    field.setAccessible(true);
                    field.set(t,columValue);
                }
                list.add(t);
            }
            return list;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     *资源释放
     */
    //关闭数据库
    public void ConnectionClose(Connection conn){
        try {
            if(conn != null){
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    //释放PreparedStatement
    public void PreparedStatementClose(PreparedStatement preparedStatement){
        try {
            if(preparedStatement != null) {
                preparedStatement.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

