package Bean.Model;

import javafx.beans.property.SimpleStringProperty;

public class PublisherFormModel {
    private SimpleStringProperty pub_name;
    private SimpleStringProperty pub_address;
    private SimpleStringProperty pub_email;
    private SimpleStringProperty pub_phone;
    private SimpleStringProperty pub_account;

    public PublisherFormModel() {
    }

    public PublisherFormModel(String pub_name, String pub_address, String pub_email, String pub_phone, String pub_account) {
        this.pub_name = new SimpleStringProperty(pub_name);
        this.pub_address = new SimpleStringProperty(pub_address);
        this.pub_email = new SimpleStringProperty(pub_email);
        this.pub_phone = new SimpleStringProperty(pub_phone);
        this.pub_account = new SimpleStringProperty(pub_account);
    }

    public String getPub_name() {
        return pub_name.get();
    }

    public SimpleStringProperty pub_nameProperty() {
        return pub_name;
    }

    public void setPub_name(String pub_name) {
        this.pub_name.set(pub_name);
    }

    public String getPub_address() {
        return pub_address.get();
    }

    public SimpleStringProperty pub_addressProperty() {
        return pub_address;
    }

    public void setPub_address(String pub_address) {
        this.pub_address.set(pub_address);
    }

    public String getPub_email() {
        return pub_email.get();
    }

    public SimpleStringProperty pub_emailProperty() {
        return pub_email;
    }

    public void setPub_email(String pub_email) {
        this.pub_email.set(pub_email);
    }

    public String getPub_phone() {
        return pub_phone.get();
    }

    public SimpleStringProperty pub_phoneProperty() {
        return pub_phone;
    }

    public void setPub_phone(String pub_phone) {
        this.pub_phone.set(pub_phone);
    }

    public String getPub_account() {
        return pub_account.get();
    }

    public SimpleStringProperty pub_accountProperty() {
        return pub_account;
    }

    public void setPub_account(String pub_account) {
        this.pub_account.set(pub_account);
    }
}
