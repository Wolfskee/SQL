package Bean.Model;

import javafx.beans.property.SimpleStringProperty;

public class OrderFormModel {
    private SimpleStringProperty order_id;
    private SimpleStringProperty buy_time;
    private SimpleStringProperty order_status;
    private SimpleStringProperty logis_id;
    private SimpleStringProperty logis_info;
    private SimpleStringProperty update_time;

    public OrderFormModel(String order_id, String buy_time, String order_status, String logis_id, String logis_info, String update_time) {
        this.order_id = new SimpleStringProperty(order_id);
        this.buy_time = new SimpleStringProperty(buy_time);
        this.order_status = new SimpleStringProperty(order_status);
        this.logis_id = new SimpleStringProperty(logis_id);
        this.logis_info = new SimpleStringProperty(logis_info);
        this.update_time = new SimpleStringProperty(update_time);
    }

    public String getOrder_id() {
        return order_id.get();
    }

    public SimpleStringProperty order_idProperty() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id.set(order_id);
    }

    public String getBuy_time() {
        return buy_time.get();
    }

    public SimpleStringProperty buy_timeProperty() {
        return buy_time;
    }

    public void setBuy_time(String buy_time) {
        this.buy_time.set(buy_time);
    }

    public String getOrder_status() {
        return order_status.get();
    }

    public SimpleStringProperty order_statusProperty() {
        return order_status;
    }

    public void setOrder_status(String order_status) {
        this.order_status.set(order_status);
    }

    public String getLogis_id() {
        return logis_id.get();
    }

    public SimpleStringProperty logis_idProperty() {
        return logis_id;
    }

    public void setLogis_id(String logis_id) {
        this.logis_id.set(logis_id);
    }

    public String getLogis_info() {
        return logis_info.get();
    }

    public SimpleStringProperty logis_infoProperty() {
        return logis_info;
    }

    public void setLogis_info(String logis_info) {
        this.logis_info.set(logis_info);
    }

    public String getUpdate_time() {
        return update_time.get();
    }

    public SimpleStringProperty update_timeProperty() {
        return update_time;
    }

    public void setUpdate_time(String update_time) {
        this.update_time.set(update_time);
    }
}
