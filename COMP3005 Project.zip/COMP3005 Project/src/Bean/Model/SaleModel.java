package Bean.Model;

import javafx.beans.property.SimpleStringProperty;

public class SaleModel {
    private SimpleStringProperty name;
    private SimpleStringProperty sale;

    public SaleModel(String name, String sale) {
        this.name = new SimpleStringProperty(name);
        this.sale = new SimpleStringProperty(sale);
    }

    public String getName() {
        return name.get();
    }

    public SimpleStringProperty nameProperty() {
        return name;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public String getSale() {
        return sale.get();
    }

    public SimpleStringProperty saleProperty() {
        return sale;
    }

    public void setSale(String sale) {
        this.sale.set(sale);
    }
}
