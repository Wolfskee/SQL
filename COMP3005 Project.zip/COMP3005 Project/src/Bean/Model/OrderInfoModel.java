package Bean.Model;

import javafx.beans.property.SimpleStringProperty;

public class OrderInfoModel extends OrderFormModel {
    private SimpleStringProperty user_id;
    private SimpleStringProperty order_address;
    private SimpleStringProperty order_phone;
    private SimpleStringProperty order_remarks;
    private SimpleStringProperty book_id;
    private SimpleStringProperty buy_num;
    private SimpleStringProperty buy_amout;

    public OrderInfoModel(String order_id, String buy_time, String order_status, String logis_id, String logis_info, String update_time,
                          String user_id, String order_address, String order_phone, String order_remarks, String book_id,
                          String buy_num, String buy_amout) {

        super(order_id, buy_time, order_status, logis_id, logis_info, update_time);
        this.user_id = new SimpleStringProperty(user_id);
        this.order_address = new SimpleStringProperty(order_address);
        this.order_phone = new SimpleStringProperty(order_phone);
        this.order_remarks = new SimpleStringProperty(order_remarks);
        this.book_id = new SimpleStringProperty(book_id);
        this.buy_num = new SimpleStringProperty(buy_num);
        this.buy_amout = new SimpleStringProperty(buy_amout);
    }

    public String getUser_id() {
        return user_id.get();
    }

    public SimpleStringProperty user_idProperty() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id.set(user_id);
    }

    public String getOrder_address() {
        return order_address.get();
    }

    public SimpleStringProperty order_addressProperty() {
        return order_address;
    }

    public void setOrder_address(String order_address) {
        this.order_address.set(order_address);
    }

    public String getOrder_phone() {
        return order_phone.get();
    }

    public SimpleStringProperty order_phoneProperty() {
        return order_phone;
    }

    public void setOrder_phone(String order_phone) {
        this.order_phone.set(order_phone);
    }

    public String getOrder_remarks() {
        return order_remarks.get();
    }

    public SimpleStringProperty order_remarksProperty() {
        return order_remarks;
    }

    public void setOrder_remarks(String order_remarks) {
        this.order_remarks.set(order_remarks);
    }

    public String getBook_id() {
        return book_id.get();
    }

    public SimpleStringProperty book_idProperty() {
        return book_id;
    }

    public void setBook_id(String book_id) {
        this.book_id.set(book_id);
    }

    public String getBuy_num() {
        return buy_num.get();
    }

    public SimpleStringProperty buy_numProperty() {
        return buy_num;
    }

    public void setBuy_num(String buy_num) {
        this.buy_num.set(buy_num);
    }

    public String getBuy_amout() {
        return buy_amout.get();
    }

    public SimpleStringProperty buy_amoutProperty() {
        return buy_amout;
    }

    public void setBuy_amout(String buy_amout) {
        this.buy_amout.set(buy_amout);
    }
}
