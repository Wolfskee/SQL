package Bean;

public class Order_detl {
    private int order_detl_id;
    private String order_id;
    private int book_id;
    private int buy_num;
    private int buy_amout;

    public Order_detl() {
    }

    public Order_detl(int order_detl_id, String order_id, int book_id, int buy_num, int buy_amout) {
        this.order_detl_id = order_detl_id;
        this.order_id = order_id;
        this.book_id = book_id;
        this.buy_num = buy_num;
        this.buy_amout = buy_amout;
    }

    public int getOrder_detl_id() {
        return order_detl_id;
    }

    public void setOrder_detl_id(int order_detl_id) {
        this.order_detl_id = order_detl_id;
    }

    public String getOrder_id() {
        return order_id;
    }

    public void setOrder_id(String order_id) {
        this.order_id = order_id;
    }

    public int getBook_id() {
        return book_id;
    }

    public void setBook_id(int book_id) {
        this.book_id = book_id;
    }

    public int getBuy_num() {
        return buy_num;
    }

    public void setBuy_num(int buy_num) {
        this.buy_num = buy_num;
    }

    public int getBuy_amout() {
        return buy_amout;
    }

    public void setBuy_amout(int buy_amout) {
        this.buy_amout = buy_amout;
    }

    @Override
    public String toString() {
        return "Order_detl{" +
                "order_detl_id=" + order_detl_id +
                ", order_id='" + order_id + '\'' +
                ", book_id=" + book_id +
                ", buy_num=" + buy_num +
                ", buy_amout=" + buy_amout +
                '}';
    }
}
