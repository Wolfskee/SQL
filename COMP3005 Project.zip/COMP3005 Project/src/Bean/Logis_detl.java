package Bean;

import sun.dc.pr.PRError;

import java.util.Date;

public class Logis_detl {
    private int logis_detl_id;
    private String logis_id;
    private String logis_info;
    private Date update_time;

    public Logis_detl() {
    }

    public int getLogis_detl_id() {
        return logis_detl_id;
    }

    public void setLogis_detl_id(int logis_detl_id) {
        this.logis_detl_id = logis_detl_id;
    }

    public String getLogis_id() {
        return logis_id;
    }

    public void setLogis_id(String logis_id) {
        this.logis_id = logis_id;
    }

    public String getLogis_info() {
        return logis_info;
    }

    public void setLogis_info(String logis_info) {
        this.logis_info = logis_info;
    }

    public Date getUpdate_time() {
        return update_time;
    }

    public void setUpdate_time(Date update_time) {
        this.update_time = update_time;
    }
}
