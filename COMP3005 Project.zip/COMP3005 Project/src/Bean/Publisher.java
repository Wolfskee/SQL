package Bean;

public class Publisher {
    private int pub_id;
    private String pub_name;
    private String pub_address;
    private String pub_email;
    private String pub_phone;
    private String pub_account;

    public Publisher() {
    }

    public Publisher(int pub_id, String pub_name, String pub_address, String pub_email, String pub_phone, String pub_account) {
        this.pub_id = pub_id;
        this.pub_name = pub_name;
        this.pub_address = pub_address;
        this.pub_email = pub_email;
        this.pub_phone = pub_phone;
        this.pub_account = pub_account;
    }

    public int getPub_id() {
        return pub_id;
    }

    public void setPub_id(int pub_id) {
        this.pub_id = pub_id;
    }

    public String getPub_name() {
        return pub_name;
    }

    public void setPub_name(String pub_name) {
        this.pub_name = pub_name;
    }

    public String getPub_address() {
        return pub_address;
    }

    public void setPub_address(String pub_address) {
        this.pub_address = pub_address;
    }

    public String getPub_email() {
        return pub_email;
    }

    public void setPub_email(String pub_email) {
        this.pub_email = pub_email;
    }

    public String getPub_phone() {
        return pub_phone;
    }

    public void setPub_phone(String pub_phone) {
        this.pub_phone = pub_phone;
    }

    public String getPub_account() {
        return pub_account;
    }

    public void setPub_account(String pub_account) {
        this.pub_account = pub_account;
    }

    @Override
    public String toString() {
        return "Publisher{" +
                "pub_id=" + pub_id +
                ", pub_name='" + pub_name + '\'' +
                ", pub_address='" + pub_address + '\'' +
                ", pub_email='" + pub_email + '\'' +
                ", pub_phone='" + pub_phone + '\'' +
                ", pub_account='" + pub_account + '\'' +
                '}';
    }
}
