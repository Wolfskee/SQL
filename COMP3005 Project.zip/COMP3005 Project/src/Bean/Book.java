package Bean;

public class Book {
    private int book_id;
    private String book_name;
    private String book_ISBN;
    private String book_author;
    private String book_genre;
    private int pub_id;
    private int book_numberOfPages;
    private Double book_price;
    private int book_stock;

    public Book() {
    }

    public Book(int book_id, String book_name, String book_ISBN, String book_author, String book_genre, int pub_id, int book_numberOfPages, Double book_price, int book_stock) {
        this.book_id = book_id;
        this.book_name = book_name;
        this.book_ISBN = book_ISBN;
        this.book_author = book_author;
        this.book_genre = book_genre;
        this.pub_id = pub_id;
        this.book_numberOfPages = book_numberOfPages;
        this.book_price = book_price;
        this.book_stock = book_stock;
    }

    public int getBook_id() {
        return book_id;
    }

    public void setBook_id(int book_id) {
        this.book_id = book_id;
    }

    public String getBook_name() {
        return book_name;
    }

    public void setBook_name(String book_name) {
        this.book_name = book_name;
    }

    public String getBook_ISBN() {
        return book_ISBN;
    }

    public void setBook_ISBN(String book_ISBN) {
        this.book_ISBN = book_ISBN;
    }

    public String getBook_author() {
        return book_author;
    }

    public void setBook_author(String book_author) {
        this.book_author = book_author;
    }

    public String getBook_genre() {
        return book_genre;
    }

    public void setBook_genre(String book_genre) {
        this.book_genre = book_genre;
    }

    public int getPub_id() {
        return pub_id;
    }

    public void setPub_id(int pub_id) {
        this.pub_id = pub_id;
    }

    public int getBook_numberOfPages() {
        return book_numberOfPages;
    }

    public void setBook_numberOfPages(int book_numberOfPages) {
        this.book_numberOfPages = book_numberOfPages;
    }

    public Double getBook_price() {
        return book_price;
    }

    public void setBook_price(Double book_price) {
        this.book_price = book_price;
    }

    public int getBook_stock() {
        return book_stock;
    }

    public void setBook_stock(int book_stock) {
        this.book_stock = book_stock;
    }
}
