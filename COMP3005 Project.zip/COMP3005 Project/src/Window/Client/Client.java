package Window.Client;

import Bean.*;
import Bean.Model.OrderFormModel;
import Utlis.DBUtlis;
import Window.Login;
import Window.Register;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.util.List;

public class Client{
    private TextField searchField;          //搜索框
    private Button searchBut;
    private DBUtlis dbUtlis = new DBUtlis();
    private static AnchorPane pane;
    private static Stage prim;
    private ChoiceBox cb;

    private static Label login;
    private static Label reg;
    private static HBox top = new HBox(15);

    public Client(){
        prim = new Stage();
        prim.setTitle("online bookstore");
        prim.setHeight(720);
        prim.setWidth(1300);
        pane = new AnchorPane();         //布局类

        URL url = getClass().getClassLoader().getResource("Img\\Client.png");
        String path = url.toExternalForm();
        //设置背景
        pane.getChildren().add(new ImageView(new Image(path,1300,720,false,false)));

        //搜索框
        HBox hBox = new HBox(5);
        searchField = new TextField();
        searchField.setPrefSize(600, 50);
        searchField.setEditable(true);
        searchField.setPromptText("Please lose the title！");

        cb = new ChoiceBox();
        ObservableList<Object> objects = FXCollections.observableArrayList();
        objects.addAll("Book Name","Author","Genre","ISBN");
        cb.setItems(objects);
        cb.setPrefSize(100.0,50.0);

        searchBut = new Button("Search");
        searchBut.setPrefSize(100,48);
        hBox.getChildren().addAll(searchField,cb,searchBut);
        pane.getChildren().add(hBox);
        AnchorPane.setLeftAnchor(hBox,300.0);
        AnchorPane.setTopAnchor(hBox,150.0);

        Top();
        topMonitor();

        Scene scene = new Scene(pane);
        prim.setScene(scene);
        prim.show();
        Monitor();
    }

    private void Monitor (){
        searchBut.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Connection conn = dbUtlis.Connection();
                List<Book> queue = null;

                if (cb.getValue() == null){
                    queue = dbUtlis.Queue(conn, "SELECT * FROM book WHERE book_name like ?", Book.class, "%" + searchField.getText() + "%");
                } else {
                    //"Book Name","Author","Genre","ISBN"
                    if ("Book Name".equals(cb.getValue())) {
                        queue = dbUtlis.Queue(conn, "SELECT * FROM book WHERE book_name like ?", Book.class, "%" + searchField.getText() + "%");

                    }  else if ("Author".equals(cb.getValue())) {
                        queue = dbUtlis.Queue(conn, "SELECT * FROM book WHERE book_author like ?", Book.class, "%" + searchField.getText() + "%");

                    } else if ("Genre".equals(cb.getValue())) {
                        queue = dbUtlis.Queue(conn, "SELECT * FROM book WHERE book_genre like ?", Book.class, "%" + searchField.getText() + "%");

                    } else if ("ISBN".equals(cb.getValue())) {
                        queue = dbUtlis.Queue(conn, "SELECT * FROM book WHERE book_ISBN like ?", Book.class, "%" + searchField.getText() + "%");
                    }
                }
                dbUtlis.ConnectionClose(conn);
                if(queue.size()>0) {
                    new bookList(pane,queue);
                }
            }
        });

    }

    public static Stage getPrim() {
        return prim;
    }

    public static void Top(){
        top.getChildren().retainAll();
        Message.setUser(null);
        top = new HBox(15);
        top.setStyle("-fx-font-size: 14;");
        login = new Label("Login");
        reg = new Label("Rgister");
        top.getChildren().addAll(login,reg);
        pane.getChildren().add(top);
        AnchorPane.setLeftAnchor(top,1150.0);
        AnchorPane.setTopAnchor(top,5.0);
    }

    public static void topMonitor(){
        login.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                new Login();
            }
        });

        reg.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                new Register();
            }
        });
    }


    public static void topMessage(User user) {

        top.getChildren().retainAll();
        top.setStyle("-fx-font-size: 14;");
        Label name = new Label(user.getUser_name());
        Label cart = new Label("shoppingTrolley");
        Label orderForm = new Label(" orderForm");
        Label exit = new Label("quit");
        top.getChildren().addAll(name,cart,orderForm,exit);
        AnchorPane.setLeftAnchor(top,970.0);

        exit.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Top();
                topMonitor();
            }
        });

        cart.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                new ShoppingTrolley(user);
            }
        });

        orderForm.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                orderFormWin(prim,user.getUser_id());
            }
        });
    }

    private static void orderFormWin(Stage main,int userid){
        Stage stage = new Stage();
        stage.setHeight(350);
        stage.setWidth(900);
        stage.setTitle("Order Form");
        stage.initOwner(main);
        stage.initModality(Modality.WINDOW_MODAL);
        AnchorPane pane = new AnchorPane();

        TableView<OrderFormModel> table = new TableView<OrderFormModel>();
        table.setPrefWidth(900.0);
        ObservableList<OrderFormModel> data = FXCollections.observableArrayList();

        DBUtlis utlis = new DBUtlis();
        Connection conn = utlis.Connection();
        List<Order> list = utlis.Queue(conn, "SELECT * FROM `order` WHERE user_id=?", Order.class,userid);
        for (int i = 0; i < list.size(); i++) {

            List<Logis_detl> queue = utlis.Queue(conn, "SELECT * FROM logis_detl WHERE logis_id = ?", Logis_detl.class, list.get(i).getLogis_id());
            if (queue.size()<=0){
                break;
            }
            Order order = list.get(i);
            Logis_detl detl = queue.get(0);
            data.add(new OrderFormModel(order.getOrder_id(),order.getBuy_time().toString(),String.valueOf(order.getOrder_status()), order.getLogis_id(),detl.getLogis_info(),detl.getUpdate_time().toString()));
        }
        utlis.ConnectionClose(conn);

        table.setEditable(true);

        TableColumn order_id = new TableColumn("order_id");
        order_id.setMinWidth(100);
        order_id.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("order_id"));

        TableColumn buy_time = new TableColumn("buy_time");
        buy_time.setMinWidth(150);
        buy_time.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("buy_time"));

        TableColumn order_status = new TableColumn("order_status");
        order_status.setMinWidth(100);
        order_status.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("order_status"));

        TableColumn logis_id = new TableColumn("logis_id");
        logis_id.setMinWidth(100);
        logis_id.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("logis_id"));

        TableColumn logis_info = new TableColumn("logis_info");
        logis_info.setMinWidth(280);
        logis_info.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("logis_info"));

        TableColumn update_time = new TableColumn("update_time");
        update_time.setMinWidth(150);
        update_time.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("update_time"));

        table.setItems(data);
        table.getColumns().addAll(order_id, buy_time, order_status,logis_id,logis_info,update_time);

        pane.getChildren().add(table);
        stage.setScene(new Scene(pane));
        stage.show();
    }

}

