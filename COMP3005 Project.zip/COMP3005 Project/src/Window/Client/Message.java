package Window.Client;

import Bean.Book;
import Bean.Car;
import Bean.Publisher;
import Bean.User;
import Utlis.DBUtlis;
import Window.Login;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.Connection;
import java.util.List;


public class Message {

    private static Stage stage;
    private Button collect;
    private static User User;
    private Book book;
    private ChoiceBox cb;
    private DBUtlis dbUtlis = new DBUtlis();

    public Message(String bookname, Book book){
        this.book= book;
        stage = new Stage();
        stage.setTitle(bookname);
        stage.setWidth(700);
        stage.setHeight(400);
        AnchorPane anchorPane = new AnchorPane();

        VBox bookimg = new VBox();
        String path = getClass().getClassLoader().getResource("Img/book\\"+book.getBook_id()+".png").toExternalForm();
        ImageView imageView = new ImageView(new Image(path, 110, 160, false, false));
        Label label = new Label(book.getBook_name());
        label.setPrefSize(110.0,10.0);
        bookimg.getChildren().addAll(imageView,label);
        anchorPane.getChildren().add(bookimg);
        AnchorPane.setTopAnchor(bookimg,30.0);
        AnchorPane.setLeftAnchor(bookimg,50.0);

        VBox nameBox = new VBox(10);
        nameBox.setStyle("-fx-font-size: 15;");

        Label name = new Label("Name : "+book.getBook_name());
        Label ISBN = new Label("ISBN : "+book.getBook_ISBN());
        Label author = new Label("Author : "+book.getBook_author());
        Label genre = new Label("Genre : "+book.getBook_genre());
        Label publisher = new Label("Publisher : "+getBook_publisherName(book.getPub_id()));
        Label numberOfPages = new Label("Number Of Pages : "+book.getBook_numberOfPages());
        Label price = new Label("Price : "+book.getBook_price());
        nameBox.getChildren().addAll(name,ISBN,author,genre,publisher,numberOfPages,price);
        anchorPane.getChildren().addAll(nameBox);
        AnchorPane.setLeftAnchor(nameBox,200.0);
        AnchorPane.setTopAnchor(nameBox,30.0);

        HBox hBox = new HBox(20);
        hBox.setStyle("-fx-font-size: 15;");
        Label label1 = new Label("Purchase quantity");
        cb = new ChoiceBox();
        ObservableList<Object> objects = FXCollections.observableArrayList();
        for (int i = 0; i <book.getBook_stock() ; i++) {
            objects.add(i+1);
        }
        cb.setItems(objects);
        hBox.getChildren().addAll(label1,cb);
        anchorPane.getChildren().add(hBox);
        AnchorPane.setTopAnchor(hBox,300.0);
        AnchorPane.setLeftAnchor(hBox,250.0);

        collect = new Button("Add to Shopping Cart");
        anchorPane.getChildren().add(collect);
        AnchorPane.setTopAnchor(collect,300.0);
        AnchorPane.setLeftAnchor(collect,500.0);

        stage.initOwner(Client.getPrim());
        stage.initModality(Modality.WINDOW_MODAL);
        stage.setScene(new Scene(anchorPane));
        stage.show();
        Monitor();
    }

    private void Monitor(){
        collect.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if(User==null) {
                    new Login();
                    return;
                }
                if(cb.getValue() == null){
                    return;
                }
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                if(isRepetition(User.getUser_id(),book.getBook_id())){
                    alert.titleProperty().set("Please do not add again!");
                    alert.headerTextProperty().set(book.getBook_name()+"It's already in your shopping cart.");
                    alert.showAndWait();
                    return;
                }
                Connection conn = dbUtlis.Connection();
                int rud = dbUtlis.RUD(conn, "INSERT INTO car(user_id,book_id,buy_num)VALUES(?,?,?);", User.getUser_id(), book.getBook_id(), cb.getValue());
                dbUtlis.ConnectionClose(conn);
                if(rud<=0){
                    alert.titleProperty().set("addition failed !");
                    alert.headerTextProperty().set(book.getBook_name()+"addition failed !");
                    alert.showAndWait();
                    return;
                } else {
                    stage.close();
                    alert.titleProperty().set("successfully added!");
                    alert.headerTextProperty().set(book.getBook_name()+"Add to your shopping cart successfully!");
                    alert.showAndWait();
                }
            }
        });
    }

    public static Bean.User getUser() {
        return User;
    }

    public static void setUser(Bean.User user) {
        User = user;
    }

    public boolean isRepetition(int userID,int bookID){
        Connection conn = dbUtlis.Connection();
        List queue = dbUtlis.Queue(conn, "SELECT * FROM car WHERE book_id= ? and user_id = ?", Car.class, bookID, userID);
        System.out.println(queue);
        if(queue.size()>0 || queue == null){
            return true;
        }
        return false;
    }

    public String getBook_publisherName(int pub_id){

        Connection conn = dbUtlis.Connection();
        List<Publisher> list = dbUtlis.Queue(conn, "SELECT * FROM publisher where pub_id = ?", Publisher.class, pub_id);
        if (list.size()<=0){
            return null;
        }
        return list.get(0).getPub_name();
    }
}
