package Window.Client;

import Bean.Book;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;

import java.util.List;

public class bookList {
    private ScrollPane sp;
    private AnchorPane pane;

    public bookList(){}

    public bookList(AnchorPane pane, List<Book> queue){
        if(queue.size() == 0){
            pane.getChildren().remove(sp);
            return;
        }
        this.pane = pane;
        FlowPane flowPane = new FlowPane();
        flowPane.setStyle("-fx-background-color: rgba(255,255,255,0.1);");
        flowPane.setMinWidth(1000);
        flowPane.setPadding(new Insets(0, 0, 0, 7));
        flowPane.setVgap(10);
        flowPane.setHgap(13);
        for (int i = 0; i < queue.size(); i++) {
            flowPane.getChildren().add(new bookList().bookVbox(queue.get(i)));
        }

        sp = new ScrollPane();
        sp.setFitToHeight(true);
        sp.setMinSize(1000.0,380.0);
        sp.setMaxSize(1000.0,380.0);
        sp.setContent(flowPane);
        pane.getChildren().addAll(sp);
        AnchorPane.setTopAnchor(sp,250.0);
        AnchorPane.setLeftAnchor(sp,150.0);
    }

    public VBox bookVbox(Book book){
        VBox vBox = new VBox();
        String path = getClass().getClassLoader().getResource("Img\\book\\"+book.getBook_id()+".png").toExternalForm();
        ImageView imageView = new ImageView(new Image(path, 110, 160, false, false));
        Label label = new Label(book.getBook_name());
        label.setPrefSize(110.0,10.0);
        vBox.getChildren().addAll(imageView,label);

        vBox.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                new Message(book.getBook_name(),book);
//                pane.getChildren();
            }
        });
        return vBox;
    }
}
