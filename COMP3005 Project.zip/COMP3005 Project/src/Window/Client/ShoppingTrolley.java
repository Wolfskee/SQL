package Window.Client;

import Bean.Book;
import Bean.Car;
import Bean.User;
import Utlis.DBUtlis;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class ShoppingTrolley{

    private ScrollPane sp;
    private FlowPane flowPane;
    private Stage prim = new Stage();;
    private AnchorPane pane = new AnchorPane();
    private DBUtlis dbUtlis = new DBUtlis();
    private double totalPrices = 0;
    private Label prices;

    public ShoppingTrolley(User user) {
        prim.setTitle(user.getUser_name()+" shopping cart");
        prim.setWidth(900);
        prim.setHeight(400);

        flowPane = new FlowPane();
        flowPane.setStyle("-fx-background-color: rgba(255,255,255,0.1);");
        flowPane.setMinWidth(850.0);
        flowPane.setPadding(new Insets(0, 0, 0, 7));
        flowPane.setVgap(10);
        flowPane.setHgap(13);

        HBox hBox = new HBox(130);
        hBox.setStyle("-fx-background-color: #A6BAC3;");
        hBox.setMinWidth(880.0);
        hBox.setMinHeight(15);
        Label cover = new Label("Cover");
        Label message = new Label("Message");
        Label price = new Label("Price");
        Label quantity = new Label("Amount");
        Label total = new Label("Total");
        hBox.getChildren().addAll(cover,message,price,quantity,total);
        flowPane.getChildren().add(hBox);

        Connection conn = dbUtlis.Connection();
        List<Car> queue = dbUtlis.Queue(conn, "SELECT * FROM car where user_id = ?", Car.class, user.getUser_id());
        List<Book> book;
        for (int i = 0; i < queue.size(); i++) {
            book = dbUtlis.Queue(conn, "SELECT * FROM book WHERE book_id = ?", Book.class, queue.get(i).getBook_id());
            if(book.size()==0) {
                break;
            }
            flowPane.getChildren().add(bookVbox(book.get(0),queue.get(i).getBuy_num(),user.getUser_id()));
        }
        dbUtlis.ConnectionClose(conn);

        sp = new ScrollPane();
        sp.setFitToHeight(true);
        sp.setMinSize(880.0,300.0);
        sp.setMaxSize(880.0,300.0);
        sp.setContent(flowPane);
        pane.getChildren().addAll(sp);

        HBox base = new HBox(15);
        prices = new Label("Total Prices : " + totalPrices);
        Button buy = new Button("BUY");
        base.getChildren().addAll(prices,buy);

        buy.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                shipping_address(user.getUser_id());
            }
        });

        pane.getChildren().add(base);
        AnchorPane.setTopAnchor(base,320.0);
        AnchorPane.setLeftAnchor(base,600.0);

        prim.setScene(new Scene(pane));
        prim.show();
    }


    public HBox bookVbox(Book book,int num,int userID){
        HBox hBox = new HBox(20);
        hBox.setMinWidth(780.0);
        String path = getClass().getClassLoader().getResource("Img\\book\\"+book.getBook_id()+".png").toExternalForm();
        ImageView imageView = new ImageView(new Image(path, 60, 100, false, false));

        VBox vBox = new VBox(10);
        vBox.setMinWidth(250.0);
        vBox.setStyle("-fx-font-size: 14;");
        Label label = new Label(book.getBook_name());
        label.setPrefSize(150.0,10.0);
        Label author = new Label("Author : "+book.getBook_author());
        author.setPrefSize(150.0,10.0);
        Label ISBN = new Label("ISBN : "+book.getBook_ISBN());
        vBox.getChildren().addAll(label,author,ISBN);

        Label price = new Label(String.valueOf(book.getBook_price()));
        price.setMinWidth(140.0);
        Label amount = new Label(String.valueOf(num));
        amount.setMinWidth(150.0);
        Label total = new Label(String.valueOf(num*book.getBook_price()));
        totalPrices = totalPrices + num*book.getBook_price();
        System.out.println(totalPrices);
        total.setMinWidth(90.0);
        Button del = new Button("delete");
        hBox.getChildren().addAll(imageView,vBox,price,amount,total,del);
        
        del.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Connection conn = dbUtlis.Connection();
                int rud = dbUtlis.RUD(conn, "DELETE FROM car WHERE book_id= ? and user_id = ?", book.getBook_id(),userID);
                if(rud>0){
                    flowPane.getChildren().remove(hBox);
                    totalPrices = totalPrices - num*book.getBook_price();
                    prices.setText("Total Prices : " + totalPrices);
                }
                dbUtlis.ConnectionClose(conn);
            }
        });
        
        return hBox;
    }

    public void shipping_address(int userID){
        Stage stage = new Stage();
        stage.setHeight(550);
        stage.setWidth(380);
        stage.setTitle("Please log in the account and continue the operation!");
        AnchorPane pane = new AnchorPane();

        VBox v1 = new VBox(26);
        v1.setStyle("-fx-font-size: 14;");
        Label address = new Label("shipping address");
        Label phone = new Label("phone");
        Label remarks = new Label("remarks");
        v1.getChildren().addAll(address,phone,remarks);

        VBox v2 = new VBox(15);
        v2.setStyle("-fx-font-size: 14;");
        TextField addressfield = new TextField();
        TextField phonefield = new TextField();
        TextField remarksfield = new TextField();
        v2.getChildren().addAll(addressfield,phonefield,remarksfield);

        pane.getChildren().addAll(v1,v2);
        AnchorPane.setTopAnchor(v1,120.0);
        AnchorPane.setLeftAnchor(v1,20.0);

        AnchorPane.setTopAnchor(v2,120.0);
        AnchorPane.setLeftAnchor(v2,150.0);

        Button buy = new Button("Confirm and pay");
        buy.setPrefSize(320.0,40.0);
        pane.getChildren().add(buy);
        AnchorPane.setTopAnchor(buy,315.0);
        AnchorPane.setLeftAnchor(buy,20.0);

        buy.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if(addressfield.getText() != null && phonefield.getText() != null && remarksfield.getText() != null){
                    //随机生成 8 位订单号
                    String order_id = String.valueOf((int)((Math.random()*9+1)*1000000));
                    //随机生成 10 位物流ID
                    String logis_id = String.valueOf((int)((Math.random()*9+1)*1000000));
                    //连接数据库
                    Connection conn = dbUtlis.Connection();
                    //向订单表插入信息
                    int rud = dbUtlis.RUD(conn, "INSERT INTO `order` (order_id, user_id, buy_time, order_status, order_address, order_phone, logis_id,order_remarks) VALUE (?,?,?,?,?,?,?,?)",
                            order_id, userID, getTime(), 0, addressfield.getText(), phonefield.getText(), logis_id,remarks.getText());
                    if(rud<=0){
                        System.out.println("向订单表插入信息失败！");
                    }
                    //向订单明细表插入信息
                    List<Car> queue = dbUtlis.Queue(conn, "SELECT * FROM car where user_id = ?", Car.class, userID);
                    List<Book> book;
                    for (int i = 0; i < queue.size(); i++) {
                        book = dbUtlis.Queue(conn, "SELECT * FROM book WHERE book_id = ?", Book.class, queue.get(i).getBook_id());
                        if(book.size()==0) {
                            break;
                        }
                        //开始循环插入
                        rud = dbUtlis.RUD(conn, "INSERT INTO order_detl (order_id, book_id, buy_num, buy_amout) VALUE (?,?,?,?)",
                                order_id, book.get(0).getBook_id(), queue.get(i).getBuy_num(), book.get(0).getBook_price());
                        if(rud<=0){
                            System.out.println("向订单明细表插入信息失败！");
                        }
                        //修改库存
                        dbUtlis.RUD(conn,"UPDATE book SET book_stock = book_stock-? where book_id = ?",queue.get(i).getBuy_num(),book.get(0).getBook_id());
                        if (book.get(0).getBook_stock()-queue.get(i).getBuy_num()<=10){
                            dbUtlis.RUD(conn,"UPDATE book SET book_stock = book_stock+100 where book_id = ?",book.get(0).getBook_id());
                            System.out.println("Send an email to "+book.get(0).getBook_name()+"'s publisher to order 100 copies");
                        }
                    }
                    //向物流明细表插入信息
                    rud = dbUtlis.RUD(conn, "INSERT INTO logis_detl (logis_id, logis_info, update_time) VALUE (?,?,?)",
                            logis_id, "To send the goods~", getTime());
                    dbUtlis.ConnectionClose(conn);
                    if(rud<=0){
                        System.out.println("向物流明细表插入信息失败！");
                        return;
                    }
                    //生成一个完整订单完成
                    deleteCar(userID);          //删除购物车里面的书
                    stage.close();
                    prim.close();
                } else {
                    System.out.println("请确保信息的完整性");
                }

            }
        });

        stage.setScene(new Scene(pane));
        stage.show();
    }

    public String getTime(){
        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        //从前端或者自己模拟一个日期格式，转为String即可
        return format.format(date);
    }

    public void deleteCar(int userid){
        Connection conn = dbUtlis.Connection();
        dbUtlis.RUD(conn, "DELETE FROM car WHERE user_id= ?", userid);
        dbUtlis.ConnectionClose(conn);
    }
}
