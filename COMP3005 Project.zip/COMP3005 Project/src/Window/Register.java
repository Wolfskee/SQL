package Window;

import Bean.User;
import Utlis.DBUtlis;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.sql.Connection;
import java.util.List;

public class Register {

    private  DBUtlis utlis = new DBUtlis();

    public Register(){
        Stage stage = new Stage();
        stage.setHeight(550);
        stage.setWidth(380);
        stage.setTitle("Register");
        AnchorPane pane = new AnchorPane();

        VBox v1 = new VBox(26);
        v1.setStyle("-fx-font-size: 14;");
        Label nmae = new Label("Nmae");
        Label password = new Label("Password");
        Label phone = new Label("Phone");
        Label address = new Label("Address");
        v1.getChildren().addAll(nmae,password,phone,address);

        VBox v2 = new VBox(15);
        v2.setStyle("-fx-font-size: 14;");
        TextField nmaefield = new TextField();
        PasswordField passwordfield = new PasswordField();
        TextField phonefield = new TextField();
        TextField addressfield = new TextField();
        v2.getChildren().addAll(nmaefield,passwordfield,phonefield,addressfield);

        pane.getChildren().addAll(v1,v2);
        AnchorPane.setTopAnchor(v1,100.0);
        AnchorPane.setLeftAnchor(v1,20.0);

        AnchorPane.setTopAnchor(v2,100.0);
        AnchorPane.setLeftAnchor(v2,150.0);

        Button buy = new Button("Register");
        buy.setPrefSize(320.0,40.0);
        pane.getChildren().add(buy);
        AnchorPane.setTopAnchor(buy,315.0);
        AnchorPane.setLeftAnchor(buy,20.0);

        buy.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                if (isNull(nmaefield,passwordfield,phonefield,addressfield)){
                    return;
                }
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                if (isexist(nmaefield.getText())){
                    alert.setTitle("User name duplication!");
                    alert.setContentText("This user name has been registered, please try another one!");
                    alert.showAndWait();
                    return;
                }
                Connection conn = utlis.Connection();
                int rud = utlis.RUD(conn, "INSERT INTO user (user_name, password, user_phone, address, permission) VALUE (?,?,?,?,?)",
                        nmaefield.getText(), passwordfield.getText(), phonefield.getText(), addressfield.getText(), 0);
                if (rud<=0){
                    return;
                } else {
                    alert.setTitle("registered successfully!");
                    alert.setContentText("Account "+nmae.getText()+" was successfully registered!");
                    alert.showAndWait();
                }
                utlis.ConnectionClose(conn);
                stage.close();
                new Login();
            }
        });

        stage.setScene(new Scene(pane));
        stage.show();
    }

    private boolean isNull(TextField ... ts){
        for (TextField t : ts){
            if (t.getText() == null || "".equals(t.getText())) {
                return true;
            }
        }
        return false;
    }

    private boolean isexist(String username){

        Connection conn = utlis.Connection();
        List queue = utlis.Queue(conn,"SELECT * FROM user WHERE user_name = ?", User.class, username);
        if(queue.size()>0){
            return true;
        }
        utlis.ConnectionClose(conn);
        return false;
    }
}
