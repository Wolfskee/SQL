package Window;

import Bean.User;
import Utlis.DBUtlis;
import Window.Client.Client;
import Window.Client.Message;
import Window.Manager.Manager;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.util.List;

public class Login {

    private TextField nameText;
    private PasswordField passText;
    private Button login;
    private Button register;
    private DBUtlis dbUtlis = new DBUtlis();
    private Stage stage;

    public Login(){
        stage = new Stage();
        stage.setHeight(550);
        stage.setWidth(380);
        stage.setTitle("Please log in the account and continue the operation!");
        AnchorPane pane = new AnchorPane();

        HBox nameBox = new HBox(35);
        Label labelName = new Label("Nmae");
        nameText = new TextField();
        nameBox.getChildren().addAll(labelName,nameText);

        HBox passBox = new HBox(10);
        Label labelPass = new Label("Password");
        passText = new PasswordField();
        passBox.getChildren().addAll(labelPass,passText);

        VBox buttonBox = new VBox(15);
        login = new Button("Login");
        login.setPrefSize(280.0,35.0);
        register = new Button("Register");
        register.setPrefSize(280.0,35.0);
        buttonBox.getChildren().addAll(login,register);

        VBox vBox = new VBox(25);
        vBox.setStyle("-fx-font-size: 15;");
        vBox.getChildren().addAll(nameBox,passBox,buttonBox);


        pane.getChildren().add(vBox);
        AnchorPane.setLeftAnchor(vBox,40.0);
        AnchorPane.setTopAnchor(vBox,120.0);

        stage.setScene(new Scene(pane));
        stage.show();
        Monitor();
    }

    public void Monitor(){
        login.setOnMouseClicked(new EventHandler<MouseEvent>()  {
            @Override
            public void handle(MouseEvent event) {
                Login();
            }
        });

        register.setOnMouseClicked(new EventHandler<MouseEvent>()  {
            @Override
            public void handle(MouseEvent event) {
                new Register();
            }
        });
    }

    public void Login(){

        String username = nameText.getText();
        String password = passText.getText();

        Connection conn = dbUtlis.Connection();
        List<User> queue = dbUtlis.Queue(conn, "SELECT * FROM user WHERE user_name=? AND password=?", User.class, username,password);
        if(queue.size()<=0){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warnings!");
            alert.setContentText("Password error or account does not exist!");
            alert.showAndWait();
            return;
        }
        if(queue.get(0).getPermission() == 1){
            new Manager();
        }
        Message.setUser(queue.get(0));
        Client.topMessage(queue.get(0));
        stage.close();
    }

}
