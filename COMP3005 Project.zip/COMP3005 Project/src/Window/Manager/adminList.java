package Window.Manager;

import Bean.Book;
import Bean.Publisher;
import Utlis.DBUtlis;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.io.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class adminList {

    private ScrollPane sp;
    private FlowPane flowPane;
    private AnchorPane prim = Manager.getContentPane();;
    private AnchorPane pane = new AnchorPane();
    private DBUtlis dbUtlis = new DBUtlis();
    private int amountbooks = 0;
    private Label prices;
    private File imgFile;
    private Stage main;

    public adminList() {

        flowPane = new FlowPane();
        flowPane.setStyle("-fx-background-color: rgba(255,255,255,0.1);");
        flowPane.setMinWidth(1300.0);
        flowPane.setPadding(new Insets(0, 0, 0, 7));
        flowPane.setVgap(10);
        flowPane.setHgap(13);

        HBox hBox = new HBox(250);
        hBox.setStyle("-fx-background-color: #A6BAC3;");
        hBox.setMinWidth(1300.0);
        hBox.setMinHeight(15);
        Label cover = new Label("Cover");
        Label message = new Label("Message");
        Label price = new Label("Price");
        Label quantity = new Label("quantity in stock");
        hBox.getChildren().addAll(cover,message,price,quantity);
        flowPane.getChildren().add(hBox);

        Connection conn = dbUtlis.Connection();
        List<Book> books = dbUtlis.Queue(conn, "SELECT * FROM book", Book.class);

        for (int i = 0; i < books.size(); i++) {
            flowPane.getChildren().add(bookVbox(books.get(i)));
            amountbooks += 1;
        }
        dbUtlis.ConnectionClose(conn);

        sp = new ScrollPane();
        sp.setFitToHeight(true);
        sp.setMinSize(1300.0,300.0);
        sp.setMaxSize(1300.0,300.0);
        sp.setContent(flowPane);
        pane.getChildren().addAll(sp);

        HBox base = new HBox(15);
        base.setStyle("-fx-font-size: 14;");
        prices = new Label("The amount of books : " + amountbooks);
        Button buy = new Button("Add new book");
        buy.setPrefWidth(300.0);
        base.getChildren().addAll(prices,buy);

        buy.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                addBook();
            }
        });

        pane.getChildren().add(base);
        AnchorPane.setTopAnchor(base,330.0);
        AnchorPane.setLeftAnchor(base,400.0);

        prim.getChildren().removeAll();
        prim.getChildren().add(pane);
    }


    public HBox bookVbox(Book book){
        HBox hBox = new HBox(20);
        hBox.setMinWidth(1000.0);
        String path = "file:\\"+System.getProperty("user.dir")+"\\src\\Img\\book\\"+book.getBook_id()+".png";
        ImageView imageView = new ImageView(new Image(path, 60, 100, false, false));

        VBox vBox = new VBox(10);
        vBox.setMinWidth(250.0);
        vBox.setStyle("-fx-font-size: 14;");
        Label label = new Label(book.getBook_name());
        label.setPrefSize(480.0,10.0);
        Label author = new Label("Author : "+book.getBook_author());
        author.setPrefSize(150.0,10.0);
        Label ISBN = new Label("ISBN : "+book.getBook_ISBN());
        vBox.getChildren().addAll(label,author,ISBN);

        Label price = new Label(String.valueOf(book.getBook_price()));
        price.setMinWidth(300.0);
        Label quantityStock = new Label(String.valueOf(book.getBook_stock()));
        quantityStock.setMinWidth(150.0);

        Button del = new Button("delete");
        hBox.getChildren().addAll(imageView,vBox,price,quantityStock,del);
        
        del.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Connection conn = dbUtlis.Connection();
                int rud = dbUtlis.RUD(conn, "DELETE FROM book WHERE book_id= ?", book.getBook_id());
                if(rud>0){
                    flowPane.getChildren().remove(hBox);
                    try{
                        new File("file:\\"+System.getProperty("user.dir")+"\\src\\Img\\book\\"+book.getBook_id()+".png").deleteOnExit();
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                }
                dbUtlis.ConnectionClose(conn);
            }
        });
        
        return hBox;
    }

    public void addBook(){
        Stage stage = new Stage();
        stage.setHeight(550);
        stage.setWidth(800);
        stage.setTitle("Please log in the account and continue the operation!");
        AnchorPane pane = new AnchorPane();

        VBox v1 = new VBox(26);
        v1.setStyle("-fx-font-size: 14;");
        Label name = new Label("name");
        Label ISBN = new Label("ISBN");
        Label author = new Label("author");
        Label genre = new Label("genre");
        Label publisher = new Label("publisher");
        Label numberOfPages = new Label("number Of Pages");
        Label price = new Label("price");
        Label inventory = new Label("inventory");

        v1.getChildren().addAll(name,ISBN,author,genre,publisher,numberOfPages,price,inventory);

        VBox v2 = new VBox(15);
        v2.setStyle("-fx-font-size: 14;");
        TextField namefield = new TextField();
        TextField ISBNfield = new TextField();
        TextField authorfield = new TextField();
        TextField genrefield = new TextField();

        //出版社
        ChoiceBox cb = new ChoiceBox();
        cb.setPrefSize(190.0,30.0);
        ObservableList<Object> objects = FXCollections.observableArrayList();
        Connection conn = dbUtlis.Connection();
        List<Publisher> list = dbUtlis.Queue(conn, "SELECT * FROM publisher", Publisher.class);
        dbUtlis.ConnectionClose(conn);
        for (int i = 0; i <list.size() ; i++) {
            objects.add(list.get(i).getPub_name());
        }
        cb.setItems(objects);

        TextField numberOfPagesfield = new TextField();
        TextField pricefield = new TextField();
        TextField inventoryfield = new TextField();

        v2.getChildren().addAll(namefield,ISBNfield,authorfield,genrefield,cb,numberOfPagesfield,pricefield,inventoryfield);

        pane.getChildren().addAll(v1,v2);
        AnchorPane.setTopAnchor(v1,30.0);
        AnchorPane.setLeftAnchor(v1,410.0);

        AnchorPane.setTopAnchor(v2,30.0);
        AnchorPane.setLeftAnchor(v2,540.0);

        //图片上传按钮
        Button uploading = new Button("Upload the book cover");
        uploading.setPrefSize(320.0,40.0);
        pane.getChildren().add(uploading);
        AnchorPane.setTopAnchor(uploading,315.0);
        AnchorPane.setLeftAnchor(uploading,20.0);

        Button add = new Button("Add book");
        add.setPrefSize(320.0,40.0);
        pane.getChildren().add(add);
        AnchorPane.setTopAnchor(add,410.0);
        AnchorPane.setLeftAnchor(add,410.0);

        String path = getClass().getClassLoader().getResource("Img\\default.png").toExternalForm();
        ImageView imageView = new ImageView(new Image(path, 170, 250, false, false));
        pane.getChildren().add(imageView);
        AnchorPane.setLeftAnchor(imageView,90.0);
        AnchorPane.setTopAnchor(imageView,30.0);

        uploading.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                FileChooser fileChooser = new FileChooser();
                configureFileChooser(fileChooser);
                File file = fileChooser.showOpenDialog(stage);
                if (file != null) {
                    imgFile = file;
                    //删除默认图片
                    pane.getChildren().remove(imageView);
                    //添加新图
                    System.out.println(file.getPath());
                    ImageView newIng = new ImageView(new Image("file:\\"+file.getPath(), 170, 250, false, false));
                    pane.getChildren().add(newIng);
                    AnchorPane.setLeftAnchor(newIng,90.0);
                    AnchorPane.setTopAnchor(newIng,30.0);
                }
            }
        });

        add.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {

                //判断是否空
                if(namefield.getText() != null && ISBNfield.getText() != null && authorfield.getText() != null &&
                        genrefield.getText() != null && cb.getValue() != null && numberOfPagesfield.getText() != null &&
                        pricefield.getText() != null && inventoryfield.getText() != null && isNumeric(inventoryfield.getText())
                        && isNumeric(pricefield.getText()) && isNumeric(numberOfPagesfield.getText()) && imgFile != null){
                    //添加操作
                    Connection conn = dbUtlis.Connection();
                    int rud = dbUtlis.RUD(conn, "INSERT INTO book(BOOK_NAME, BOOK_ISBN, BOOK_AUTHOR, BOOK_GENRE, pub_id, BOOK_NUMBEROFPAGES, BOOK_PRICE, BOOK_STOCK)value (?,?,?,?,?,?,?,?)",
                            namefield.getText(),ISBNfield.getText(),authorfield.getText(), genrefield.getText(),getPub_id(cb.getValue().toString()),
                            numberOfPagesfield.getText(),pricefield.getText(),inventoryfield.getText());
                    dbUtlis.ConnectionClose(conn);
                    if(rud>0){
                        //复制图片操作
                        String path = System.getProperty("user.dir")+"\\src\\Img\\book\\"+getMaxID()+".png";
                        System.out.println(path);
                        copy(imgFile,path,1024);
                        stage.close();
                        prim.getChildren().removeAll();
                        new adminList();
                    }
                } else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Incomplete or incorrect information!");
                    alert.setContentText("Please check if the information you entered is complete or correct!");
                    alert.showAndWait();
                }
            }
        });

        stage.setScene(new Scene(pane));
        stage.show();
    }

    private void configureFileChooser(
            final FileChooser fileChooser) {
        fileChooser.setTitle("View Pictures");
        fileChooser.setInitialDirectory(
                new File(System.getProperty("user.home"))
        );
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("PNG", "*.png")
        );
    }

    public static void copy(File source, String dest, int bufferSize) {
        InputStream in = null;
        OutputStream out = null;
        try {
            in = new FileInputStream(source);
            out = new FileOutputStream(new File(dest));

            byte[] buffer = new byte[bufferSize];
            int len;

            while ((len = in.read(buffer)) > 0) {
                out.write(buffer, 0, len);
            }
            out.flush();
        } catch (Exception e) {
            System.out.println(e);
        } finally {
            try {
                if (in != null)
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                if(out != null)
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public boolean deleteFile(String sPath) {
        boolean flag = false;
        File file = new File(sPath);
        // 路径为文件且不为空则进行删除
        if (file.isFile() && file.exists()) {
            file.delete();
            flag = true;
        }
        return flag;
    }

    private int getMaxID(){
        int id = 0;
        Connection conn = new DBUtlis().Connection();
        try {
            PreparedStatement pr = conn.prepareStatement("select MAX(book_id) from book");
            ResultSet resultSet = pr.executeQuery();
            while (resultSet.next()){
                id = resultSet.getInt(1);
            }
            System.out.println(id);
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return id;
    }

    public static boolean isNumeric(String str){
        for (int i = str.length();--i>=0;){
            if (!Character.isDigit(str.charAt(i))){
                return false;
            }
        }
        return true;
    }

    public int getPub_id(String pub_name){

        Connection conn = dbUtlis.Connection();
        List<Publisher> list = dbUtlis.Queue(conn, "SELECT * FROM publisher where pub_name = ?", Publisher.class, pub_name);
        if (list.size()>0){
            return list.get(0).getPub_id();
        }
        return 1;
    }
}
