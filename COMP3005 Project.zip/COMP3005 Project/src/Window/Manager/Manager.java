package Window.Manager;

import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Separator;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class Manager {

    private Stage stage;
    private static AnchorPane contentPane;

    public Manager() {
        stage = new Stage();
        stage = new Stage();
        stage.setTitle("Online bookstore administrator backstage");
        stage.setHeight(790);
        stage.setWidth(1315);
        AnchorPane pane = new AnchorPane();

        String path = "file:\\"+System.getProperty("user.dir")+"\\src\\Img\\adminbj.png";
        ImageView imageView = new ImageView(new Image(path, 1300, 200, false, false));

        Label log = new Label("Online bookstore background management system");
        log.setStyle("-fx-font-size: 30;"+"-fx-font-weight: bold;");
        AnchorPane.setLeftAnchor(log,240.0);
        AnchorPane.setTopAnchor(log,240.0);

        Separator br = new Separator();
        br.setStyle("-fx-background-color: #000000");
        br.setPrefSize(1300.0,2);
        AnchorPane.setTopAnchor(br,340.0);

        HBox hBox = new HBox(20);
        //本书店的书的列表
        //点击可以删除书
        Button list = new Button("Inquire about the collection of our books");
        Button publisher = new Button("Publisher List");
        Button orderinfo = new Button("Order Info");
        Button sale = new Button("Sale");
        Stage finalStage = stage;
        list.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                new adminList();
            }
        });

        publisher.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                new PublisherWin(finalStage);
            }
        });

        orderinfo.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                new OrderList();
            }
        });

        sale.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                new Sale();
            }
        });

        hBox.getChildren().addAll(list,publisher,orderinfo,sale);
        AnchorPane.setTopAnchor(hBox,300.0);
        AnchorPane.setLeftAnchor(hBox,400.0);

        contentPane = new AnchorPane();
        contentPane.setPrefSize(1300.0,400.0);
        AnchorPane.setTopAnchor(contentPane,350.0);

        pane.getChildren().addAll(hBox,imageView,log,br,contentPane);

        stage.setScene(new Scene(pane));
        stage.show();
    }

    public static AnchorPane getContentPane() {
        return contentPane;
    }
}
