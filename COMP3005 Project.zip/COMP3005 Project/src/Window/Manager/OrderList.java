package Window.Manager;

import Bean.*;
import Bean.Model.OrderFormModel;
import Bean.Model.OrderInfoModel;
import Utlis.DBUtlis;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.util.Callback;

import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class OrderList {

    private AnchorPane pane = Manager.getContentPane();
    private DBUtlis utlis = new DBUtlis();

    public OrderList(){
        pane.getChildren().clear();
        AnchorPane my = new AnchorPane();

        TableView<OrderInfoModel> table = new TableView<OrderInfoModel>();
        table.setPrefWidth(1300.0);
        table.setPrefHeight(300);
        ObservableList<OrderInfoModel> data = FXCollections.observableArrayList();

        Connection conn = utlis.Connection();
        List<Order> orders = utlis.Queue(conn, "SELECT * FROM `order` where order_status != 1", Order.class);
        for (int i = 0; i < orders.size(); i++) {
            Order order = orders.get(i);
            List<Order_detl> order_detl = utlis.Queue(conn, "SELECT * FROM order_detl where order_id=?", Order_detl.class, order.getOrder_id());
            if (order_detl.size()<=0){
                break;
            }
            Order_detl detl = order_detl.get(0);
            List<Logis_detl> logis_detl = utlis.Queue(conn, "SELECT * FROM logis_detl where logis_id = ?", Logis_detl.class, order.getLogis_id());
            if (logis_detl.size()<=0){
                break;
            }
            Logis_detl logisDetl = logis_detl.get(0);

            data.add(new OrderInfoModel(order.getOrder_id(),order.getBuy_time().toString(),String.valueOf(order.getOrder_status()),order.getLogis_id(),
                    logisDetl.getLogis_info(),logisDetl.getUpdate_time().toString(),String.valueOf(order.getUser_id()),order.getOrder_address(),order.getOrder_phone(),
                    order.getOrder_remarks(),String.valueOf(detl.getBook_id()),String.valueOf(detl.getBuy_num()),String.valueOf(detl.getBuy_amout())));
        }
        utlis.ConnectionClose(conn);

        table.setEditable(true);

        TableColumn order_id = new TableColumn("order_id");
        order_id.setMinWidth(100);
        order_id.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("order_id"));

        TableColumn buy_time = new TableColumn("buy_time");
        buy_time.setMinWidth(100);
        buy_time.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("buy_time"));

        TableColumn order_status = new TableColumn("order_status");
        order_status.setMinWidth(100);
        order_status.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("order_status"));

        TableColumn logis_id = new TableColumn("logis_id");
        logis_id.setMinWidth(100);
        logis_id.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("logis_id"));

        TableColumn logis_info = new TableColumn("logis_info");
        logis_info.setMinWidth(100);
        logis_info.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("logis_info"));

        TableColumn update_time = new TableColumn("update_time");
        update_time.setMinWidth(100);
        update_time.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("update_time"));

        TableColumn user_id = new TableColumn("user_id");
        user_id.setMinWidth(100);
        user_id.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("user_id"));

        TableColumn order_address = new TableColumn("order_address");
        order_address.setMinWidth(100);
        order_address.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("order_address"));

        TableColumn order_phone = new TableColumn("order_phone");
        order_phone.setMinWidth(100);
        order_phone.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("order_phone"));

        TableColumn order_remarks = new TableColumn("order_remarks");
        order_remarks.setMinWidth(100);
        order_remarks.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("order_remarks"));

        TableColumn book_id = new TableColumn("book_id");
        book_id.setMinWidth(100);
        book_id.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("book_id"));

        TableColumn buy_num = new TableColumn("buy_num");
        buy_num.setMinWidth(100);
        buy_num.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("buy_num"));

        TableColumn buy_amout = new TableColumn("buy_amout");
        buy_amout.setMinWidth(100);
        buy_amout.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("buy_amout"));

        AnchorPane alterPane = new AnchorPane();
        alterPane.setPrefSize(1300.0,100.0);
        AnchorPane.setTopAnchor(alterPane,300.0);

        table.setItems(data);
        table.getColumns().addAll(order_id, buy_time, order_status, logis_id, logis_info, update_time,
                user_id,order_address,order_phone,order_remarks,book_id,buy_num,buy_amout);

        table.setRowFactory(new Callback<TableView<OrderInfoModel>, TableRow<OrderInfoModel>>() {
            @Override
            public TableRow<OrderInfoModel> call(TableView<OrderInfoModel> param) {
                return new TableRowControl(alterPane);
            }
        });


        my.getChildren().add(table);
        pane.getChildren().addAll(my,alterPane);
    }
}

class TableRowControl extends TableRow<OrderInfoModel> {
    public TableRowControl(AnchorPane alterPane){
        super();
        this.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                alterPane.getChildren().clear();

                Button button = new Button("shipments");
                button.setPrefSize(330.0,40.0);
                alterPane.getChildren().add(button);
                AnchorPane.setTopAnchor(button,30.0);
                AnchorPane.setLeftAnchor(button,460.0);

                button.setOnMouseClicked(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent event) {
                        DBUtlis utlis = new DBUtlis();
                        Connection conn = utlis.Connection();
                        int i = utlis.RUD(conn, "UPDATE logis_detl SET logis_info = ?,update_time = ? where logis_id = ?",
                                "Warehouse delivered", getTime(), TableRowControl.this.getItem().getLogis_id());
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        if(i<=0){
                            alert.setTitle("Warnings!");
                            alert.setContentText("Password error or account does not exist!");
                            alert.showAndWait();
                            return;
                        }
                        alert.setTitle("Warnings!");
                        alert.setContentText("Password error or account does not exist!");
                        alert.showAndWait();
                        alterPane.getChildren().clear();
                        TableRowControl.this.getItem().setLogis_info("Warehouse delivered");
                        TableRowControl.this.getItem().setUpdate_time(getTime());
                    }
                });
            }
        });
    }

    public String getTime(){
        Date date = new Date();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return format.format(date);
    }
}