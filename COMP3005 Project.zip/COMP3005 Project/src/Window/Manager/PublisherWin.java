package Window.Manager;

import Bean.*;
import Bean.Model.OrderFormModel;
import Bean.Model.PublisherFormModel;
import Utlis.DBUtlis;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

import java.sql.Connection;
import java.util.List;

public class PublisherWin {

    private DBUtlis utlis = new DBUtlis();

    public PublisherWin(Stage main){
        Stage stage = new Stage();
        stage.setHeight(470);
        stage.setWidth(900);
        stage.setTitle("Publisher Form");
        stage.initOwner(main);
        stage.initModality(Modality.WINDOW_MODAL);
        AnchorPane pane = new AnchorPane();

        TableView<PublisherFormModel> table = new TableView<PublisherFormModel>();
        table.setPrefWidth(900.0);
        table.setPrefHeight(300);
        ObservableList<PublisherFormModel> data = FXCollections.observableArrayList();

        Connection conn = utlis.Connection();
        List<Publisher> publishers = utlis.Queue(conn, "SELECT * FROM publisher", Publisher.class);
        for (int i = 0; i < publishers.size(); i++) {
            Publisher pub = publishers.get(i);
            data.add(new PublisherFormModel(pub.getPub_name(),pub.getPub_address(),pub.getPub_email(),pub.getPub_phone(),pub.getPub_account()));
        }
        utlis.ConnectionClose(conn);

        table.setEditable(true);

        TableColumn pub_name = new TableColumn("pub_name");
        pub_name.setMinWidth(200);
        pub_name.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("pub_name"));

        TableColumn pub_address = new TableColumn("pub_address");
        pub_address.setMinWidth(250);
        pub_address.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("pub_address"));

        TableColumn pub_email = new TableColumn("pub_email");
        pub_email.setMinWidth(150);
        pub_email.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("pub_email"));

        TableColumn pub_phone = new TableColumn("pub_phone");
        pub_phone.setMinWidth(100);
        pub_phone.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("pub_phone"));

        TableColumn pub_account = new TableColumn("pub_account");
        pub_account.setMinWidth(200);
        pub_account.setCellValueFactory(
                new PropertyValueFactory<OrderFormModel, String>("pub_account"));

        table.setItems(data);
        table.getColumns().addAll(pub_name, pub_address, pub_email,pub_phone,pub_account);

        HBox hBox = new HBox(6);
        TextField name = new TextField();
        name.setPrefWidth(197);
        TextField address = new TextField();
        address.setPrefWidth(244);
        TextField email = new TextField();
        email.setPrefWidth(144);
        TextField phone = new TextField();
        phone.setPrefWidth(94);
        TextField account = new TextField();
        account.setPrefWidth(175);
        hBox.getChildren().addAll(name,address,email,phone,account);
        AnchorPane.setTopAnchor(hBox,315.0);

        Button add = new Button("Add a new publisher");
        add.setPrefSize(360.0,45.0);
        AnchorPane.setTopAnchor(add,360.0);
        AnchorPane.setLeftAnchor(add,250.0);

        add.setOnMouseClicked(new EventHandler<MouseEvent>() {
            @Override
            public void handle(MouseEvent event) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                if (isNull(name,address,email,phone,account)){
                    alert.setTitle("Please check for information integrity");
                    alert.setContentText("Please check for information integrity!");
                    alert.showAndWait();
                    return;
                }
                if (isexist(name.getText())){
                    alert.setTitle("Do not add repeatedly");
                    alert.setContentText("This publishing house has been registered in this system, do not add repeatedly!");
                    alert.showAndWait();
                    return;
                }

                Connection conn = utlis.Connection();
                int rud = utlis.RUD(conn, "INSERT INTO publisher (pub_name, pub_address, pub_email, pub_phone, pub_account) VALUE (?,?,?,?,?)",
                        name.getText(), address.getText(), email.getText(), phone.getText(), account.getText());
                if (rud<=0){
                    alert.setTitle("addition failed ");
                    alert.setContentText("addition failed!");
                    alert.showAndWait();
                    return;
                }
                alert.setTitle("successfully added");
                alert.setContentText("successfully added !");
                alert.showAndWait();

                utlis.ConnectionClose(conn);
                stage.close();
                new PublisherWin(main);
            }
        });

        pane.getChildren().addAll(table,hBox,add);
        stage.setScene(new Scene(pane));
        stage.show();
    }

    private boolean isNull(TextInputControl... ts){
        for (TextInputControl t : ts){
            if (t.getText() == null) {
                return true;
            }
        }
        return false;
    }

    private boolean isexist(String name){

        Connection conn = utlis.Connection();
        List queue = utlis.Queue(conn,"SELECT * FROM publisher where pub_name =?", Publisher.class, name);
        if(queue.size()>0){
            return true;
        }
        utlis.ConnectionClose(conn);
        return false;
    }
}
