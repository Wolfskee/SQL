package Window.Manager;

import Bean.*;
import Bean.Model.SaleModel;
import Utlis.DBUtlis;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;

import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Sale {

    private DBUtlis dbUtlis = new DBUtlis();
    private AnchorPane pane = Manager.getContentPane();

    public Sale(){
        pane.getChildren().clear();

        AnchorPane salePane = new AnchorPane();

        TableView genre = tableViewSale("genre","Sale",1);
        TableView author = tableViewSale("author","Sale",1);
        salePane.getChildren().addAll(genre,author);
        AnchorPane.setLeftAnchor(author,650.0);

        pane.getChildren().add(salePane);
    }


    private TableView tableViewSale(String name,String saleName,int type){
        TableView<SaleModel> table = new TableView<SaleModel>();
        table.setPrefWidth(600.0);
        table.setPrefHeight(300);
        ObservableList<SaleModel> data = FXCollections.observableArrayList();

        table.setEditable(true);

        TableColumn book_author = new TableColumn(name);
        book_author.setMinWidth(300);
        book_author.setCellValueFactory(
                new PropertyValueFactory<SaleModel, String>("name"));

        TableColumn author_sale = new TableColumn(saleName);
        author_sale.setMinWidth(300);
        author_sale.setCellValueFactory(
                new PropertyValueFactory<SaleModel, String>("sale"));

        table.getColumns().addAll(book_author,author_sale);
        Map<String,Double> genreSale = new HashMap<>();

        Connection conn = dbUtlis.Connection();
        List<Order_detl> orderDetls = dbUtlis.Queue(conn, "SELECT * FROM order_detl", Order_detl.class);
        for (int i = 0; i < orderDetls.size(); i++) {
            List<Book> books = dbUtlis.Queue(conn, "SELECT * FROM book where book_id = ?", Book.class,orderDetls.get(i).getBook_id());
            if (books.size() != 1) {
                continue;
            }
            if (type == 1){
                String genre = books.get(0).getBook_genre();               //获取书的类型
                if (genreSale.get(genre)==null){
                    //没有这个类型则创建类型key
                    genreSale.put(genre,orderDetls.get(i).getBuy_num()*orderDetls.get(i).getBuy_amout()*1.0);
                } else {
                    genreSale.put(genre,genreSale.get(genre)+orderDetls.get(i).getBuy_num()*orderDetls.get(i).getBuy_amout()*1.0);
                }
            } else if (type == 2){
                String author = books.get(0).getBook_author();               //获取书的作者
                if (genreSale.get(author)==null){
                    //没有这个类型则创建类型key
                    genreSale.put(author,orderDetls.get(i).getBuy_num()*orderDetls.get(i).getBuy_amout()*1.0);
                } else {
                    genreSale.put(author,genreSale.get(author)+orderDetls.get(i).getBuy_num()*orderDetls.get(i).getBuy_amout()*1.0);
                }
            }

        }
        dbUtlis.ConnectionClose(conn);
        for(Map.Entry<String, Double> entry : genreSale.entrySet()){
            data.add(new SaleModel(entry.getKey(),String.valueOf(entry.getValue())));
        }
        //数据绑定
        table.setItems(data);

        return table;
    }
}
